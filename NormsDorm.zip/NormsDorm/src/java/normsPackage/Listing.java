package normsPackage;
import java.io.OutputStream;
import java.io.Serializable;

public class Listing implements Serializable {
    private String username;
    private String title;
    private String price;
    private byte[] bytes;
    private String base64Image;
    private String location;
    private String category;
    private String condition;
    private String color;
    private String description;
    private String email;
    
    public Listing () {
        username = "";
        title = "";
        price = "";
        bytes = null;
        base64Image = "";
        location = "";
        category = "";
        condition = "";
        color = "";
        description = "";
        email = "";
    }
    
    public Listing(String username, String title, String price, byte[] bytes, String base64Image, String location, String category, String condition, String color, String description, String email) {
        this.username = username;
        this.title = title;
        this.price = price;
        this.bytes = bytes;
        this.base64Image = base64Image;
        this.location = location;
        this.category = category;
        this.condition = condition;
        this.color = color;
        this.description = description;
        this.email = email;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getTitle() {
        return title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getPrice() {
        return price;
    }
    
    public void setPrice(String price) {
        this.price = price;
    }
    
    public byte[] getBytes() {
        return bytes;
    }
    
    public void setBytes(byte[] bytes) {
        this.bytes = bytes;
    }
    
    public String getBase64Image() {
        return base64Image;
    }
 
    public void setBase64Image(String base64Image) {
        this.base64Image = base64Image;
    }
    
    public String getLocation() {
        return location;
    }
    
    public void setLocation(String location) {
        this.location = location;
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public String getCondition() {
        return condition;
    }
    
    public void setCondition(String condition) {
        this.condition = condition;
    }
    
    public String getColor() {
        return color;
    }
    
    public void setColor(String color) {
        this.color = color;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
}
