package normsPackage;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Random;
import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpSession;

public class DBUtil {
    
    public static boolean addUser(User user) {

        DbConnection dbCon = new DbConnection();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = connection.prepareStatement("INSERT INTO users VALUES (?,?,?,?,?,?)");
            
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getFullname());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getPassword());
            ps.setString(5, user.getCode());
            ps.setBoolean(6, user.getVerify());
            ps.executeUpdate();

        } catch (SQLException se) {
            if (((se.getErrorCode() == 30000) && ("23505".equals(se.getSQLState())))) {
                System.out.println("ERROR: Could not insert record into USER; dup primary key: " + user.getUsername());
            } else {
                System.out.println("ERROR: Could not add row to USER table: " + user.getUsername() + " " + se.getCause());
            }
            return false;
        } catch (Exception e) {
            System.out.println("ERROR: Could not add row to USER table: " + user.getUsername());
            return false;
        }
        System.out.println("Added user to USER table: " + user.getUsername());

        return true;
    }
    
    public static User verify(String email, String password, String code) {

        DbConnection dbCon = new DbConnection();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps;
        User theUser = null;
        
        try {
            ps = connection.prepareStatement("UPDATE users SET verify = true WHERE email = ? AND code = ?");
            ps.setString(1, email);
            ps.setString(2, code);
            ps.executeUpdate();
            
            theUser = (User) DBUtil.tryLogin(email, password);

        } catch (SQLException se) {
            
        } catch (Exception e) {
            
        }
        return theUser;
    }
    
    public static User tryLogin(String email, String password) {

        DbConnection dbCon = new DbConnection();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps;
        User theUser = null;
        
        try {
            ps = connection.prepareStatement("SELECT * FROM users WHERE email = ? AND password = ?");
            
            ps.setString(1, email);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String username = rs.getString("username");
                String fullname = rs.getString("fullname");
                email = rs.getString("email");
                password = rs.getString("password");
                String code = rs.getString("code");
                boolean verify = rs.getBoolean("verify");
                if (verify == true) {
                    theUser = new User(username, fullname, email, password, code, verify);
                    return theUser;
                }
            }

        } catch (SQLException se) {
            
        } catch (Exception e) {
            
        }
        return theUser;
    }
    
    
    public static User update(String username, String fullname, String email, String password) {

        DbConnection dbCon = new DbConnection();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps;
        User theUser = null;
        
        try {
            ps = connection.prepareStatement("UPDATE users SET username = ?, fullname = ?, password = ? WHERE email = ?");
            ps.setString(1, username);
            ps.setString(2, fullname);
            ps.setString(3, password);
            ps.setString(4, email);
            ps.executeUpdate();
            
            ps = connection.prepareStatement("SELECT * FROM users WHERE email = ?");
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                username = rs.getString("username");
                fullname = rs.getString("fullname");
                email = rs.getString("email");
                password = rs.getString("password");
                String code = rs.getString("code");
                boolean verify = rs.getBoolean("verify");
                if (verify == true) {
                    theUser = new User(username, fullname, email, password, code, verify);
                    return theUser;
                }
            }

        } catch (SQLException se) {
            
        } catch (Exception e) {
            
        }
        return theUser;
    }
    
    public static void addListing (String username, String title, String price, InputStream inputStream, String location, String category, String condition, String color, String description, String email)  {
        DbConnection dbCon = new DbConnection();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = connection.prepareStatement("INSERT INTO listings VALUES (?,?,?,?,?,?,?,?,?,?)");
            ps.setString(1, username);
            ps.setString(2, title);
            ps.setString(3, price);
            ps.setBlob(4, inputStream);
            ps.setString(5, location);
            ps.setString(6, category);
            ps.setString(7, condition);
            ps.setString(8, color);
            ps.setString(9, description);
            ps.setString(10, email);
            ps.executeUpdate();
        } catch (SQLException se) {
            
        } catch (Exception e) {
            
        }
        
    }
    
    public static ArrayList<Listing> getAllListings ()  {
        DbConnection dbCon = new DbConnection();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps;
        Blob blob = null;
        byte[] imgData = null;
        ArrayList<Listing> listings = new ArrayList<>();
        
        try {
            ps = connection.prepareStatement("SELECT * FROM listings");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String username = rs.getString("username");
                String title = rs.getString("title");
                String price = rs.getString("price");
                
                blob = rs.getBlob("image");
                imgData = blob.getBytes(1,(int)blob.length());
                
                InputStream inputStream = blob.getBinaryStream();
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096];
                int bytesRead = -1;   
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);                  
                }               
                byte[] imageBytes = outputStream.toByteArray();
                String base64Image = Base64.getEncoder().encodeToString(imageBytes);          
                inputStream.close();
                outputStream.close();
                
                
                String location = rs.getString("location");
                String category = rs.getString("category");
                String condition = rs.getString("cndition");
                String color = rs.getString("color");
                String description = rs.getString("description");
                String email = rs.getString("email");
                Listing listing = new Listing(username, title, price, imgData, base64Image, location, category, condition, color, description, email);
                listings.add(listing);
            }

        } catch (SQLException se) {
            
        } catch (Exception e) {
            
        }
        return listings;
    }
    
    public static ArrayList<Listing> getUserListings (String username)  {
        DbConnection dbCon = new DbConnection();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps;
        Blob blob = null;
        byte[] imgData = null;
        ArrayList<Listing> listings = new ArrayList<>();
        
        try {
            ps = connection.prepareStatement("SELECT * FROM listings where username = ?");
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                username = rs.getString("username");
                String title = rs.getString("title");
                String price = rs.getString("price");
                blob = rs.getBlob("image");
                imgData = blob.getBytes(1,(int)blob.length());
                
                InputStream inputStream = blob.getBinaryStream();
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096];
                int bytesRead = -1;   
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);                  
                }               
                byte[] imageBytes = outputStream.toByteArray();
                String base64Image = Base64.getEncoder().encodeToString(imageBytes);          
                inputStream.close();
                outputStream.close();
                String location = rs.getString("location");
                String category = rs.getString("category");
                String condition = rs.getString("cndition");
                String color = rs.getString("color");
                String description = rs.getString("description");
                String email = rs.getString("email");
                Listing listing = new Listing(username, title, price, imgData, base64Image, location, category, condition, color, description, email);
                listings.add(listing);
            }

        } catch (SQLException se) {
            
        } catch (Exception e) {
            
        }
        return listings;
    }
    
    public static Listing getCurrentListing (String title)  {
        DbConnection dbCon = new DbConnection();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps;
        Blob blob = null;
        byte[] imgData = null;
        Listing currentListing = new Listing();
        
        try {
            ps = connection.prepareStatement("SELECT * FROM listings where title = ?");
            ps.setString(1, title);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String username = rs.getString("username");
                title = rs.getString("title");
                String price = rs.getString("price");
                blob = rs.getBlob("image");
                imgData = blob.getBytes(1,(int)blob.length());
                
                InputStream inputStream = blob.getBinaryStream();
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096];
                int bytesRead = -1;   
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);                  
                }               
                byte[] imageBytes = outputStream.toByteArray();
                String base64Image = Base64.getEncoder().encodeToString(imageBytes);          
                inputStream.close();
                outputStream.close();
                String location = rs.getString("location");
                String category = rs.getString("category");
                String condition = rs.getString("cndition");
                String color = rs.getString("color");
                String description = rs.getString("description");
                String email = rs.getString("email");
                currentListing = new Listing(username, title, price, imgData, base64Image, location, category, condition, color, description, email);
            }

        } catch (SQLException se) {
            
        } catch (Exception e) {
            
        }
        return currentListing;
    }
    
    public static void deleteListing (String title)  {
        DbConnection dbCon = new DbConnection();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = connection.prepareStatement("DELETE FROM listings WHERE title = ?");
            ps.setString(1, title);
            ps.executeUpdate();
            

        } catch (SQLException se) {
            
        } catch (Exception e) {
            
        }
    }
    
    public static ArrayList<Listing> getSearchListings (String category, String condition, String location, String color)  {
        DbConnection dbCon = new DbConnection();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps;
        Blob blob = null;
        byte[] imgData = null;
        ArrayList<Listing> listings = new ArrayList<>();
        
        try {
            ps = connection.prepareStatement("SELECT * FROM listings WHERE category LIKE ? AND cndition LIKE ? AND location LIKE ? AND color LIKE ?");
            if (category != null) {
                ps.setString(1, category);
            } else { ps.setString(1, "%"); }
            if (condition != null) {
                ps.setString(2, condition);
            } else { ps.setString(2, "%"); }
            if (location != null) {
                ps.setString(3, location);
            } else { ps.setString(3, "%"); }
            if (color != null) {
                ps.setString(4, color);
            } else { ps.setString(4, "%"); }
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                String username = rs.getString("username");
                String title = rs.getString("title");
                String price = rs.getString("price");
                blob = rs.getBlob("image");
                imgData = blob.getBytes(1,(int)blob.length());
                
                InputStream inputStream = blob.getBinaryStream();
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                byte[] buffer = new byte[4096];
                int bytesRead = -1;   
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);                  
                }               
                byte[] imageBytes = outputStream.toByteArray();
                String base64Image = Base64.getEncoder().encodeToString(imageBytes);          
                inputStream.close();
                outputStream.close();
                
                location = rs.getString("location");
                category = rs.getString("category");
                condition = rs.getString("cndition");
                color = rs.getString("color");
                String description = rs.getString("description");
                String email = rs.getString("email");
                Listing listing = new Listing(username, title, price, imgData, base64Image, location, category, condition, color, description, email);
                listings.add(listing);
            }

        } catch (SQLException se) {
            
        } catch (Exception e) {
            
        }
        return listings;
    }
}
