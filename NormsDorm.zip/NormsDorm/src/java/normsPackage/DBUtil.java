
package normsPackage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class DBUtil {
    
    private static String dbURL = "jdbc:mysql://localhost:3306";
    private static String schemaName = "norm";
    private static String dbUsername = "root";
    private static String dbPassword = "root"; //helloworld
    private static Connection connection;
    
    public static boolean addUser(User user) {

        DbConnection dbCon = new DbConnection();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = connection.prepareStatement("INSERT INTO user VALUES ( ?, ?, ?, ? )");
            
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getName());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getPassword());
            ps.executeUpdate();

        } catch (SQLException se) {
            if (((se.getErrorCode() == 30000) && ("23505".equals(se.getSQLState())))) {
                System.out.println("ERROR: Could not insert record into USER; dup primary key: " + user.getUsername());
            } else {
                System.out.println("ERROR: Could not add row to USER table: " + user.getUsername() + " " + se.getCause());
            }
            return false;
        } catch (Exception e) {
            System.out.println("ERROR: Could not add row to USER table: " + user.getUsername());
            return false;
        }
        System.out.println("Added user to USER table: " + user.getUsername());

        return true;
    }
    
    
    public static User tryLogin(String email, String password) {

        DbConnection dbCon = new DbConnection();
        Connection connection = DbConnection.getConnection();
        PreparedStatement ps;
        
        try {
            ps = connection.prepareStatement("INSERT INTO user VALUES ( ?, ?, ?, ? )");
            
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getName());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getPassword());
            ps.executeUpdate();

        } catch (SQLException se) {
            System.out.println("ERROR: Could not insert record into USER; dup primary key: " + user.getUsername());
            return false;
        } catch (Exception e) {
            System.out.println("ERROR: Could not add row to USER table: " + user.getUsername());
            return false;
        }
        System.out.println("Added user to USER table: " + user.getUsername());

        return true;
    }
    
}
